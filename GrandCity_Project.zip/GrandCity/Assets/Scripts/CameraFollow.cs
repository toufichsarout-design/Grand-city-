using UnityEngine;

/// <summary>
/// Grand City - Camera Follow
/// Smooth third-person camera for player and car
/// </summary>
public class CameraFollow : MonoBehaviour
{
    public Transform target;
    public float distance = 8f;
    public float height = 4f;
    public float smoothSpeed = 10f;
    public float rotationSpeed = 3f;

    private float currentYaw = 0f;
    private float currentPitch = 20f;

    void LateUpdate()
    {
        if (target == null) return;

        // Touch/mouse rotation
        if (Input.touchCount == 2 || Input.GetMouseButton(1))
        {
            currentYaw += Input.GetAxis("Mouse X") * rotationSpeed;
            currentPitch -= Input.GetAxis("Mouse Y") * rotationSpeed;
            currentPitch = Mathf.Clamp(currentPitch, 5f, 60f);
        }

        Quaternion rotation = Quaternion.Euler(currentPitch, currentYaw, 0);
        Vector3 desiredPos = target.position - rotation * Vector3.forward * distance + Vector3.up * height;

        transform.position = Vector3.Lerp(transform.position, desiredPos, smoothSpeed * Time.deltaTime);
        transform.LookAt(target.position + Vector3.up * 1.5f);
    }

    public void SetTarget(Transform newTarget)
    {
        target = newTarget;
    }
}

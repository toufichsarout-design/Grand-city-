using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Grand City - UI Manager
/// Handles HUD, menus, and mobile buttons
/// </summary>
public class UIManager : MonoBehaviour
{
    [Header("HUD")]
    public Text moneyText;
    public Text wantedLevelText;
    public Slider healthBar;
    public Slider staminaBar;
    public GameObject missionPanel;
    public Text missionText;

    [Header("Mobile Buttons")]
    public GameObject enterCarButton;
    public GameObject exitCarButton;
    public GameObject attackButton;
    public GameObject jumpButton;

    [Header("Minimap")]
    public RawImage minimapImage;
    public Transform minimapPlayer;

    private int wantedLevel = 0;
    private float playerHealth = 100f;

    void Start()
    {
        UpdateHUD();
        SetCarButtons(false);
    }

    public void UpdateMoney(int amount)
    {
        if (moneyText) moneyText.text = "$" + amount.ToString("N0");
    }

    public void UpdateHealth(float health)
    {
        playerHealth = health;
        if (healthBar) healthBar.value = health / 100f;
    }

    public void UpdateStamina(float stamina)
    {
        if (staminaBar) staminaBar.value = stamina / 100f;
    }

    public void SetWantedLevel(int level)
    {
        wantedLevel = Mathf.Clamp(level, 0, 5);
        if (wantedLevelText)
            wantedLevelText.text = new string('★', wantedLevel) + new string('☆', 5 - wantedLevel);
    }

    public void ShowMission(string text)
    {
        if (missionPanel) missionPanel.SetActive(true);
        if (missionText) missionText.text = text;
    }

    public void HideMission()
    {
        if (missionPanel) missionPanel.SetActive(false);
    }

    public void SetCarButtons(bool inCar)
    {
        if (enterCarButton) enterCarButton.SetActive(!inCar);
        if (exitCarButton) exitCarButton.SetActive(inCar);
    }

    void UpdateHUD()
    {
        UpdateHealth(playerHealth);
        SetWantedLevel(wantedLevel);
    }
}

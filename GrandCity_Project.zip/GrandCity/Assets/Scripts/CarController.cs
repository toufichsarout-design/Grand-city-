using UnityEngine;

/// <summary>
/// Grand City - Car Controller
/// Handles car driving with mobile touch input
/// </summary>
public class CarController : MonoBehaviour
{
    [Header("Car Settings")]
    public float motorForce = 1500f;
    public float brakeForce = 3000f;
    public float maxSteerAngle = 30f;
    public float maxSpeed = 120f;

    [Header("Wheel Colliders")]
    public WheelCollider frontLeftWheel;
    public WheelCollider frontRightWheel;
    public WheelCollider rearLeftWheel;
    public WheelCollider rearRightWheel;

    [Header("Wheel Meshes")]
    public Transform frontLeftMesh;
    public Transform frontRightMesh;
    public Transform rearLeftMesh;
    public Transform rearRightMesh;

    [Header("Mobile UI")]
    public Joystick steerJoystick;

    private float currentMotor;
    private float currentSteering;
    private bool isBraking;
    private bool playerInCar = false;
    private PlayerController player;
    public Transform exitPoint;

    void Update()
    {
        if (!playerInCar) return;
        GetInput();
        UpdateWheelMeshes();

        // Exit car - press E or button
        if (Input.GetKeyDown(KeyCode.E))
            OnPlayerExit();
    }

    void FixedUpdate()
    {
        if (!playerInCar) return;
        ApplyMotor();
        ApplySteering();
        ApplyBrakes();
        LimitSpeed();
    }

    void GetInput()
    {
        if (steerJoystick != null)
        {
            currentSteering = steerJoystick.Horizontal;
            currentMotor = steerJoystick.Vertical;
        }
        else
        {
            currentSteering = Input.GetAxis("Horizontal");
            currentMotor = Input.GetAxis("Vertical");
        }

        isBraking = Input.GetKey(KeyCode.Space);
    }

    void ApplyMotor()
    {
        rearLeftWheel.motorTorque = currentMotor * motorForce;
        rearRightWheel.motorTorque = currentMotor * motorForce;
    }

    void ApplySteering()
    {
        float steer = maxSteerAngle * currentSteering;
        frontLeftWheel.steerAngle = steer;
        frontRightWheel.steerAngle = steer;
    }

    void ApplyBrakes()
    {
        float brake = isBraking ? brakeForce : 0f;
        frontLeftWheel.brakeTorque = brake;
        frontRightWheel.brakeTorque = brake;
        rearLeftWheel.brakeTorque = brake;
        rearRightWheel.brakeTorque = brake;
    }

    void LimitSpeed()
    {
        if (GetComponent<Rigidbody>().velocity.magnitude > maxSpeed / 3.6f)
        {
            GetComponent<Rigidbody>().velocity = 
                GetComponent<Rigidbody>().velocity.normalized * (maxSpeed / 3.6f);
        }
    }

    void UpdateWheelMeshes()
    {
        UpdateWheelPose(frontLeftWheel, frontLeftMesh);
        UpdateWheelPose(frontRightWheel, frontRightMesh);
        UpdateWheelPose(rearLeftWheel, rearLeftMesh);
        UpdateWheelPose(rearRightWheel, rearRightMesh);
    }

    void UpdateWheelPose(WheelCollider col, Transform mesh)
    {
        if (mesh == null) return;
        col.GetWorldPose(out Vector3 pos, out Quaternion rot);
        mesh.position = pos;
        mesh.rotation = rot;
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") && !playerInCar)
            OnPlayerEnter(other.GetComponent<PlayerController>());
    }

    void OnPlayerEnter(PlayerController p)
    {
        player = p;
        playerInCar = true;
        player.EnterCar();
        player.transform.SetParent(transform);
        player.transform.localPosition = Vector3.zero;
    }

    public void OnPlayerExit()
    {
        if (player == null) return;
        player.transform.SetParent(null);
        player.ExitCar(exitPoint != null ? exitPoint.position : transform.position + Vector3.right * 2f);
        playerInCar = false;
        player = null;
    }
}

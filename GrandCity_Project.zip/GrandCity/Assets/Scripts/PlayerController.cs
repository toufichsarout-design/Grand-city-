using UnityEngine;

/// <summary>
/// Grand City - Player Controller
/// Handles on-foot movement, running, and jumping
/// </summary>
public class PlayerController : MonoBehaviour
{
    [Header("Movement")]
    public float walkSpeed = 4f;
    public float runSpeed = 8f;
    public float jumpForce = 5f;

    [Header("References")]
    public Joystick moveJoystick;       // Assign mobile joystick UI
    public Animator animator;

    private Rigidbody rb;
    private bool isGrounded;
    private bool inCar = false;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    void Update()
    {
        if (inCar) return;
        HandleMovement();
        HandleJump();
        UpdateAnimation();
    }

    void HandleMovement()
    {
        float h = 0f, v = 0f;

        // Mobile joystick input
        if (moveJoystick != null)
        {
            h = moveJoystick.Horizontal;
            v = moveJoystick.Vertical;
        }
        else
        {
            // Keyboard fallback (testing in editor)
            h = Input.GetAxis("Horizontal");
            v = Input.GetAxis("Vertical");
        }

        bool running = Input.GetKey(KeyCode.LeftShift);
        float speed = running ? runSpeed : walkSpeed;

        Vector3 move = new Vector3(h, 0f, v).normalized * speed;
        move.y = rb.velocity.y;
        rb.velocity = move;

        // Rotate player toward movement
        if (move.magnitude > 0.1f)
        {
            Vector3 dir = new Vector3(h, 0, v);
            transform.rotation = Quaternion.Slerp(
                transform.rotation,
                Quaternion.LookRotation(dir),
                10f * Time.deltaTime
            );
        }
    }

    void HandleJump()
    {
        if (Input.GetButtonDown("Jump") && isGrounded)
        {
            rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
        }
    }

    void UpdateAnimation()
    {
        float speed = new Vector3(rb.velocity.x, 0, rb.velocity.z).magnitude;
        if (animator != null)
        {
            animator.SetFloat("Speed", speed);
            animator.SetBool("IsGrounded", isGrounded);
        }
    }

    void OnCollisionStay(Collision col)
    {
        if (col.gameObject.CompareTag("Ground"))
            isGrounded = true;
    }

    void OnCollisionExit(Collision col)
    {
        if (col.gameObject.CompareTag("Ground"))
            isGrounded = false;
    }

    // Called when player enters a car
    public void EnterCar()
    {
        inCar = true;
        GetComponent<MeshRenderer>().enabled = false;
        rb.isKinematic = true;
    }

    public void ExitCar(Vector3 exitPosition)
    {
        inCar = false;
        transform.position = exitPosition;
        GetComponent<MeshRenderer>().enabled = true;
        rb.isKinematic = false;
    }
}

using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

/// <summary>
/// Grand City - Mission Manager
/// Handles missions, objectives, and rewards
/// </summary>
public class MissionManager : MonoBehaviour
{
    [System.Serializable]
    public class Mission
    {
        public string missionName;
        public string description;
        public int rewardMoney;
        public Transform targetLocation;
        public bool isCompleted;
    }

    [Header("Missions")]
    public List<Mission> missions = new List<Mission>();
    public int currentMissionIndex = 0;

    [Header("UI")]
    public Text missionNameText;
    public Text missionDescText;
    public Text moneyText;
    public GameObject missionCompletePanel;

    private int playerMoney = 0;

    void Start()
    {
        LoadMissions();
        ShowCurrentMission();
    }

    void LoadMissions()
    {
        // Sample missions - add your own!
        missions.Add(new Mission {
            missionName = "First Job",
            description = "Drive to the warehouse",
            rewardMoney = 500
        });
        missions.Add(new Mission {
            missionName = "Street Race",
            description = "Win the race at the docks",
            rewardMoney = 1000
        });
        missions.Add(new Mission {
            missionName = "Getaway",
            description = "Escape the police",
            rewardMoney = 2000
        });
    }

    void ShowCurrentMission()
    {
        if (currentMissionIndex >= missions.Count) return;
        Mission m = missions[currentMissionIndex];
        if (missionNameText) missionNameText.text = m.missionName;
        if (missionDescText) missionDescText.text = m.description;
    }

    public void CompleteMission()
    {
        if (currentMissionIndex >= missions.Count) return;

        Mission m = missions[currentMissionIndex];
        m.isCompleted = true;
        playerMoney += m.rewardMoney;

        if (moneyText) moneyText.text = "$" + playerMoney.ToString("N0");
        if (missionCompletePanel) missionCompletePanel.SetActive(true);

        Debug.Log($"Mission Complete: {m.missionName} | Reward: ${m.rewardMoney}");
    }

    public void NextMission()
    {
        if (missionCompletePanel) missionCompletePanel.SetActive(false);
        currentMissionIndex++;
        if (currentMissionIndex < missions.Count)
            ShowCurrentMission();
        else
            Debug.Log("All missions complete!");
    }
}

# 🏙️ Grand City — Open World Mobile Game

A GTA-style open world Android game built with Unity.

## 🎮 Game Features
- Open world city exploration
- Drive cars freely
- Missions & combat system
- Character customization
- Mobile touch controls (Android & iOS)

## 🛠️ Built With
- Unity 2022 LTS
- C# scripting
- Android Build Support

## 🚀 How to Open the Project
1. Install [Unity Hub](https://unity.com/download)
2. Add Unity **2022.3 LTS** with **Android Build Support**
3. Clone this repo:
```bash
git clone https://github.com/YOUR_USERNAME/GrandCity.git
```
4. Open Unity Hub → **Add Project** → select the `GrandCity` folder
5. Open the scene: `Assets/Scenes/GameScene.unity`

## 📱 Build for Android (Play Store)
1. Unity → **File → Build Settings**
2. Select **Android** → Switch Platform
3. **Player Settings**:
   - Package Name: `com.yourname.grandcity`
   - Minimum API: Android 7.0 (API 24)
   - Target API: Android 14
4. Click **Build** → generates `.aab` file
5. Upload `.aab` to [Google Play Console](https://play.google.com/console)

## 📁 Project Structure
```
GrandCity/
├── Assets/
│   ├── Scripts/
│   │   ├── PlayerController.cs     ← Character movement
│   │   ├── CarController.cs        ← Car driving
│   │   ├── MissionManager.cs       ← Mission system
│   │   ├── UIManager.cs            ← HUD & menus
│   │   └── CameraFollow.cs         ← Camera tracking
│   ├── Scenes/
│   │   └── GameScene.unity
│   └── Prefabs/
│       ├── Player/
│       ├── Vehicles/
│       └── City/
├── ProjectSettings/
├── .gitignore
└── README.md
```

## 👨‍💻 Developer
- Made by: **YOUR NAME**
- Version: 1.0.0

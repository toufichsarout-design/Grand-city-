# 🚀 Grand City — GitHub + Play Store Upload Guide

---

## STEP 1 — Install Git
Download from: https://git-scm.com/downloads
Install it, then open a terminal/command prompt.

---

## STEP 2 — Create GitHub Repo
1. Go to https://github.com
2. Click the **+** button → **New repository**
3. Name it: `GrandCity`
4. Keep it **Public** (or Private)
5. ❌ Do NOT add README (we have one already)
6. Click **Create repository**

---

## STEP 3 — Upload to GitHub
Open terminal in your GrandCity folder and run these commands ONE BY ONE:

```bash
git init
git add .
git commit -m "Grand City - Initial game project"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/GrandCity.git
git push -u origin main
```

⚠️ Replace YOUR_USERNAME with your actual GitHub username!

---

## STEP 4 — Open in Unity
1. Install Unity Hub: https://unity.com/download
2. Install Unity 2022.3 LTS
   - In Unity Hub → Installs → Add → 2022.3 LTS
   - Check "Android Build Support" ✅
   - Check "Android SDK & NDK Tools" ✅
3. Open Hub → Add Project → Select GrandCity folder
4. Open GameScene from Assets/Scenes/

---

## STEP 5 — Build the Android App
In Unity:
1. File → Build Settings
2. Select **Android**
3. Click **Switch Platform** (wait ~2 min)
4. Click **Player Settings**:
   - Company Name: YourName
   - Product Name: Grand City
   - Package Name: com.yourname.grandcity
   - Minimum API Level: Android 7.0 (API 24)
5. Click **Build**
6. Name the file: GrandCity.aab
7. Wait for it to build ✅

---

## STEP 6 — Publish to Play Store
1. Go to https://play.google.com/console
2. Create developer account ($25 one-time fee)
3. Click **Create app**
4. Fill in:
   - App name: Grand City
   - Language: English
   - App type: Game
5. Go to **Production → Create release**
6. Upload your **GrandCity.aab** file
7. Fill in the store listing:
   - Description
   - Screenshots (at least 2)
   - Icon (512x512 PNG)
   - Feature graphic (1024x500 PNG)
8. Submit for review (takes 1-7 days)

---

## ✅ You're done!

Your game will be live on the Play Store after Google reviews it.

---

## 💡 Tips
- Test on a real Android phone before submitting
- Use Unity's "Build and Run" to test directly on phone
- Add your phone in Android Developer Options → USB Debugging
- Screenshot your game for store graphics
